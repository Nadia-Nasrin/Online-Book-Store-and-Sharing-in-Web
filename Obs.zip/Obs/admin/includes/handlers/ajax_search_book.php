<?php

include('../../config/config.php');
include('../../includes/classes/User.php');

$query = $_POST['query'];
$userLoggedIn = $_POST['userLoggedIn'];

$names = explode(" ", $query); //query split into array at ' '

if(strpos($query, '_') !== false) {
  //If query contains an _ , assume user is searching for username (first_last)
  $usersReturnedQuery = mysqli_query($con, "SELECT * FROM posts WHERE book_name LIKE '$query' LIMIT 8");
} 
if($query != '') {
  //if query is not blank
  while($row = mysqli_fetch_array($usersReturnedQuery)) {
    $user = new User($con, $userLoggedIn);
    if($row['username'] != $userLoggedIn) {
      //get mutual friends
      $mutual_friends = $user->getMutualFriends($row['username']) . ' friends in common.';
    } else {
      $mutual_friends = '';
    }

    echo "<div class='resultDisplay'>
            <div class='liveSearchProfilePic'>
              <img src='" . $row['profile_pic'] . "'>
            </div>
            <a href='" . $row['username'] . "'>
              <div class='liveSearchText'>
                " . $row['first_name'] . ' ' . $row['last_name'] . "
                <p id='grey'>" . $mutual_friends . " </p>
              </div>
            </a>
          </div>";
  };
}

 ?>
