<?php
// Turn off error reporting
error_reporting(0);

// Report runtime errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);

// Report all errors
error_reporting(E_ALL);

// Same as error_reporting(E_ALL);
ini_set("error_reporting", E_ALL);

// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE);
class Post {
  private $user_obj;
  private $con;

  public function __construct($con, $user) {
    $this->con = $con;
    $this->user_obj = new User($con, $user); //New instance of User class
  }
  
  

  public function submitPost($body,$book_name,$category,$deal_type,$price, $user_to,$imageName) {
    $body = strip_tags($body); //Removes html
    $body = mysqli_real_escape_string($this->con, $body); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $body); //Delete all spaces


    $book_name = strip_tags($book_name); //Removes html
    $book_name = mysqli_real_escape_string($this->con, $book_name); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $book_name); //Delete all spaces

    $category = strip_tags($category); //Removes html
    $category = mysqli_real_escape_string($this->con, $category); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $category); //Delete all spaces

    $deal_type = strip_tags($deal_type); //Removes html
    $deal_type = mysqli_real_escape_string($this->con, $deal_type); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $deal_type); //Delete all spaces

    $price = strip_tags($price); //Removes html
    $price = mysqli_real_escape_string($this->con, $price); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $price); //Delete all spaces


    //Confirms there is text within the post
      if($check_empty != '') {
        $date_added = date("Y-m-d H:i:s"); //Current date and time
        $added_by = $this->user_obj->getUsername(); //Get username from User.php

          //If user is on own profile, user_to is 'none'
          if($user_to == $added_by) {
            $user_to = 'none';
          }

          //Insert Post (id, vody, added_by, user_to, date_added, user_closed, deleted, likes)
          $query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'no', 'no', '0','$book_name','$category','$deal_type','$price','$imageName','0','0','0','0')"); //Insert into DB

          if($imageName != "") {
      $query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'no', 'no', '0','$book_name','$category','$deal_type','$price','0','0','0','0')"); //Insert into 
      }
          $returned_id = mysqli_insert_id($this->con); //Returns the id of the post just submitted

          //Notifications
          if($user_to != 'none') {
            $notification = new Notification($this->con, $added_by);
            $notification->insertNotification($returned_id, $user_to, 'profile_post');
          }

          //Update Post Count for User
          $num_posts = $this->user_obj->getNumPosts(); //Get number of posts from User.php
          $num_posts++;
          $update_query = mysqli_query($this->con, "UPDATE users SET num_posts='$num_posts' WHERE username='$added_by'");
      }
  }
   public function requestbook($body,$book_name,$deal_type,$price, $user_to,$imageName) {
    $body = strip_tags($body); //Removes html
    $body = mysqli_real_escape_string($this->con, $body); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $body); //Delete all spaces


    $book_name = strip_tags($book_name); //Removes html
    $book_name = mysqli_real_escape_string($this->con, $book_name); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $book_name); //Delete all spaces

    $category = strip_tags($category); //Removes html
    $category = mysqli_real_escape_string($this->con, $category); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $category); //Delete all spaces

    $deal_type = strip_tags($deal_type); //Removes html
    $deal_type = mysqli_real_escape_string($this->con, $deal_type); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $deal_type); //Delete all spaces

    $price = strip_tags($price); //Removes html
    $price = mysqli_real_escape_string($this->con, $price); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $price); //Delete all spaces


    //Confirms there is text within the post
      if($check_empty != '') {
        $date_added = date("Y-m-d H:i:s"); //Current date and time
        $added_by = $this->user_obj->getUsername(); //Get username from User.php

          //If user is on own profile, user_to is 'none'
          if($user_to == $added_by) {
            $user_to = 'none';
          }

          //Insert Post (id, vody, added_by, user_to, date_added, user_closed, deleted, likes)
          $query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'no', 'no', '0','$book_name','0','$deal_type','0','$imageName','0')"); //Insert into DB

          if($imageName != "") {
      $query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'no', 'no', '0','$book_name','0','$deal_type','0','0')"); //Insert into 
      }
          $returned_id = mysqli_insert_id($this->con); //Returns the id of the post just submitted

          //Notifications
          if($user_to != 'none') {
            $notification = new Notification($this->con, $added_by);
            $notification->insertNotification($returned_id, $user_to, 'profile_post');
          }

          //Update Post Count for User
          $num_posts = $this->user_obj->getNumPosts(); //Get number of posts from User.php
          $num_posts++;
          $update_query = mysqli_query($this->con, "UPDATE users SET num_posts='$num_posts' WHERE username='$added_by'");
      }
  }
public function submitMyPost($body,$book_name,$category,$deal_type,$price, $user_to,$imageName,$number_of_books) {
    $body = strip_tags($body); //Removes html
    $body = mysqli_real_escape_string($this->con, $body); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $body); //Delete all spaces


    $book_name = strip_tags($book_name); //Removes html
    $book_name = mysqli_real_escape_string($this->con, $book_name); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $book_name); //Delete all spaces

    $category = strip_tags($category); //Removes html
    $category = mysqli_real_escape_string($this->con, $category); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $category); //Delete all spaces

    $deal_type = strip_tags($deal_type); //Removes html
    $deal_type = mysqli_real_escape_string($this->con, $deal_type); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $deal_type); //Delete all spaces

    $price = strip_tags($price); //Removes html
    $price = mysqli_real_escape_string($this->con, $price); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $price); //Delete all spaces


    $number_of_books = strip_tags($number_of_books); //Removes html
    $number_of_books = mysqli_real_escape_string($this->con, $number_of_books); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $number_of_books); //Delete all spaces


    //Confirms there is text within the post
      if($check_empty != '') {
        $date_added = date("Y-m-d H:i:s"); //Current date and time
        $added_by = $this->user_obj->getUsername(); //Get username from User.php

          //If user is on own profile, user_to is 'none'
          if($user_to == $added_by) {
            $user_to = 'none';
          }

          //Insert Post (id, vody, added_by, user_to, date_added, user_closed, deleted, likes)
          $query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'Yes', 'Yes', '0','$book_name','$category','$deal_type','$price','$imageName','$number_of_books','0','0','0')"); //Insert into DB

          if($imageName != "") {
      $query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'Yes', 'Yes', '0','$book_name','$category','$deal_type','$price','$number_of_books','0','0','0')"); //Insert into 
      }
          $returned_id = mysqli_insert_id($this->con); //Returns the id of the post just submitted

          //Notifications
          if($user_to != 'none') {
            $notification = new Notification($this->con, $added_by);
            $notification->insertNotification($returned_id, $user_to, 'profile_post');
          }

          //Update Post Count for User
          $num_posts = $this->user_obj->getNumPosts(); //Get number of posts from User.php
          $num_posts++;
          $update_query = mysqli_query($this->con, "UPDATE users SET num_posts='$num_posts' WHERE username='$added_by'");
      }
  }

  public function submitSaleHistory($book_name,$owner,$price,$number_of_books,$description) {
   
    $book_name = strip_tags($book_name); //Removes html
    $book_name = mysqli_real_escape_string($this->con, $book_name); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $book_name); //Delete all spaces


    $owner = strip_tags($owner); //Removes html
    $owner = mysqli_real_escape_string($this->con, $owner); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $owner); //Delete all spaces

   
   
    $price = strip_tags($price); //Removes html
    $price = mysqli_real_escape_string($this->con, $price); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $price); //Delete all spaces

    $number_of_books = strip_tags($number_of_books); //Removes html
    $number_of_books = mysqli_real_escape_string($this->con, $number_of_books); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $number_of_books); //Delete all spaces

    $description = strip_tags($description); //Removes html
    $description = mysqli_real_escape_string($this->con, $description); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $description); //Delete all spaces


    //Confirms there is text within the post
      if($check_empty != '') {
        $date_added = date("Y-m-d H:i:s"); //Current date and time
        $added_by = $this->user_obj->getUsername(); //Get username from User.php

          //If user is on own profile, user_to is 'none'
          if($user_to == $added_by) {
            $user_to = 'none';
          }

          $data_query = mysqli_query($this->con, "SELECT * FROM posts WHERE book_name='$book_name'");
          $row = mysqli_fetch_array($data_query);
          $number_of_books1 = $row['number_of_books'];
            
          if ($number_of_books1<=0|| $number_of_books1<$number_of_books) {
          "<h1>oihgui</h1>";
          }else{

           $query = mysqli_query($this->con, "INSERT INTO sell_history VALUES('','$owner', '$book_name', '$price', '$number_of_books', '$description',CURRENT_TIMESTAMP())"); //Insert 

      
          $returned_id = mysqli_insert_id($this->con); //Returns the id of the post just submitted

          //Notifications
          if($user_to != 'none') {
            $notification = new Notification($this->con, $added_by);
            $notification->insertNotification($returned_id, $user_to, 'profile_post');
          }

          //Update Post Count for User
          $num_posts = $this->user_obj->getNumPosts(); //Get number of posts from User.php
          $num_posts++;
          $update_query = mysqli_query($this->con, "UPDATE posts SET number_of_books=number_of_books-'$number_of_books' WHERE book_name='$book_name'");
      }
      }
  }
public function submitRentHistory($body,$book_name,$return_date,$customer_name,$owner) {
    $body = strip_tags($body); //Removes html
    $body = mysqli_real_escape_string($this->con, $body); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $body); //Delete all spaces

  $book_name = strip_tags($book_name); //Removes html
    $book_name = mysqli_real_escape_string($this->con, $book_name); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $book_name); //Delete all spaces

  $return_date = strip_tags($return_date); //Removes html
    $return_date = mysqli_real_escape_string($this->con, $return_date); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $return_date); //Delete all spaces

  $customer_name = strip_tags($customer_name); //Removes html
    $customer_name = mysqli_real_escape_string($this->con, $customer_name); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $customer_name); //Delete all spaces

     $owner = strip_tags($owner); //Removes html
    $owner = mysqli_real_escape_string($this->con, $owner); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $owner); //Delete all spaces

 //Confirms there is text within the post
      if($check_empty != '') {
        $date_added = date("Y-m-d H:i:s"); //Current date and time
        $added_by = $this->user_obj->getUsername(); //Get username from User.php

          //If user is on own profile, user_to is 'none'
          if($user_to == $added_by) {
            $user_to = 'none';
          }
     $data_query = mysqli_query($this->con, "SELECT * FROM posts WHERE book_name='$book_name'");
          $row = mysqli_fetch_array($data_query);
          $number_of_books1 = $row['number_of_books'];
 
         
          if ($number_of_books1==0) {
          "<h1>oihgui</h1>";
          }else{

           $query = mysqli_query($this->con, "INSERT INTO rent_history VALUES('','$owner', '$customer_name', '$book_name', '1', '$return_date', '$body')"); //Insert 
//
          //Insert Post (id, vody, added_by, user_to, date_added, user_closed, deleted, likes)
        /*  $query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'Yes', 'Yes', '0','$book_name','$category','$deal_type','0','$imageName','$number_of_books')"); //Insert into DB*/

    
          $returned_id = mysqli_insert_id($this->con); //Returns the id of the post just submitted

          //Notifications
          if($user_to != 'none') {
            $notification = new Notification($this->con, $added_by);
            $notification->insertNotification($returned_id, $user_to, 'profile_post');
          }

          //Update Post Count for User
         /* $num_posts = $this->user_obj->getNumPosts(); //Get number of posts from User.php
          $num_posts++;*/
          $update_query = mysqli_query($this->con, "UPDATE posts SET number_of_books=number_of_books-1 WHERE book_name='$book_name'");
          }
        }
      
  }
public function updateabook($id,$price,$deal_type,$discount,$start_d_date,$last_d_date) {
   

    $id = strip_tags($id); //Removes html
    $id = mysqli_real_escape_string($this->con, $id); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $id); //Delete all spaces

 
    $deal_type = strip_tags($deal_type); //Removes html
    $deal_type = mysqli_real_escape_string($this->con, $deal_type); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $deal_type); //Delete all spaces

    $price = strip_tags($price); //Removes html
    $price = mysqli_real_escape_string($this->con, $price); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $price); //Delete all spaces

    $discount = strip_tags($discount); //Removes html
    $discount = mysqli_real_escape_string($this->con, $discount); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $discount); //Delete all spaces

    $start_d_date = strip_tags($start_d_date); //Removes html
    $start_d_date = mysqli_real_escape_string($this->con, $start_d_date); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $start_d_date); //Delete all spaces

    $last_d_date = strip_tags($last_d_date); //Removes html
    $last_d_date = mysqli_real_escape_string($this->con, $last_d_date); //Protects DB from non conforming chars
    $check_empty = preg_replace('/\s+/', '', $last_d_date); //Delete all spaces
  $date_added = date("Y-m-d H:i:s");
         
         $query=mysqli_query($this->con,"UPDATE posts SET deal_type='$deal_type',price='$price',deleted='no',discount='$discount',start_d_date='$start_d_date',last_d_date='$last_d_date',date_added='$date_added' WHERE id='$id'");

//
          //Insert Post (id, vody, added_by, user_to, date_added, user_closed, deleted, likes)
        /*  $query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'Yes', 'Yes', '0','$book_name','$category','$deal_type','0','$imageName','$number_of_books')"); //Insert into DB*/

    
          $returned_id = mysqli_insert_id($this->con); //Returns the id of the post just submitted

          //Notifications
          if($user_to != 'none') {
            $notification = new Notification($this->con, $added_by);
            $notification->insertNotification($returned_id, $user_to, 'profile_post');
          }


          //Update Post Count for User
         /* $num_posts = $this->user_obj->getNumPosts(); //Get number of posts from User.php
          $num_posts++;
          $update_query = mysqli_query($this->con, "UPDATE users SET num_posts='$num_posts' WHERE username='$added_by'");*/
      
  }public function loadUserList($data, $limit) {
    $page = $data['page'];
    $userLoggedIn = $this->user_obj->getUsername();

    if($page == 1) {
      $start = 0;
    } else {
      $start = ($page - 1) + $limit;
    };

    $str = ''; //String to return, initialize
    $data_query = mysqli_query($this->con, "SELECT * FROM users  ORDER BY id DESC");

    if(mysqli_num_rows($data_query) > 0) {
      //There are results...
      $num_iterations = 0; //Number of results checked (not necs posted)
      $count = 1;
 $str .= "<div class='status_post' >
                      <div class='post_profile_pic'>
                       
                     
                      <div class='posted_by' style='color:#bdc3c7;'>
                        <a href=''> </a>  &nbsp;&nbsp;&nbsp;&nbsp;<span class='time_message'></span><br>
                        
                      </div>
                     
                       <table border='1' style='font-size: 12px !important;' >
                        <tr>
                         <th>Image</th>
                          <th> Name </th>
                             <th>Email </th>
                               
                               
                                         
                        </tr>"
                        ;
        while($row = mysqli_fetch_array($data_query)) {
          $id = $row['id'];
          $first_name = $row['first_name'];
          $last_name = $row['last_name'];
          $name=$first_name.' '.$last_name;
          $email = $row['email'];
       $imageName = '../'.$row['profile_pic'];
        
          ?>

              

         <?php
                       $str .=" 
                            <td><img src=$imageName width='120px'></td>
                          <td>$name</td>
                             <td>$email </td>
                               
                                 
                        </tr>
                        "?>

                        <?php  } "
                      </table>
                      
                        <br>
                      </div>
                       </div>
                     
                    </div>
                   
                    <hr>";
          //End of friends of check
          ?>
      

          <?php
      //End while loop

      if($count > $limit) {
        $str .= "<input type='hidden' class='nextPage' value='" . ($page + 1) > "'>
                <input type='hidden' class='noMorePosts' value='false'>";
      } else {
        $str .= "<input type='hidden' class='noMorePosts' value='true'><p style='text-align: center;'></p>";
      }
    } //End if(mysqli_num_rows($data_query))
      echo $str;
  }
 public function loadPostsMine($data, $limit) {
    $page = $data['page'];
    $userLoggedIn = $this->user_obj->getUsername();

    if($page == 1) {
      $start = 0;
    } else {
      $start = ($page - 1) + $limit;
    };

    $str = ''; //String to return, initialize
    $data_query = mysqli_query($this->con, "SELECT * FROM posts  ORDER BY id DESC");

    if(mysqli_num_rows($data_query) > 0) {
      //There are results...
      $num_iterations = 0; //Number of results checked (not necs posted)
      $count = 1;
 $str .= "<div class='status_post' >
                      <div class='post_profile_pic'>
                       
                     
                      <div class='posted_by' style='color:#bdc3c7;'>
                        <a href=''> </a>  &nbsp;&nbsp;&nbsp;&nbsp;<span class='time_message'></span><br>
                        
                      </div>
                     
                       <table border='1' style='font-size: 12px !important;' >
                        <tr>
                        <th>Image</th>
                          <th>Book Name </th>
                           <th>Added By</th>
                             <th>Category </th>
                               
                                   <th>Number of Books</th>
                                   <th>Description</th>
                                      <th>Date</th>
                                      
                                         
                        </tr>"
                        ;
        while($row = mysqli_fetch_array($data_query)) {
          $id = $row['id'];
          $body = $row['body'];
          $book_name = $row['book_name'];
          $category = $row['category'];
          $deal_type = $row['deal_type'];
          $price = $row['price'];
          $added_by = $row['added_by'];
          $date_time = $row['date_added'];
           $imageName = $row['image_name'];
$number_of_books = $row['number_of_books'];
        
          ?>

              

         <?php
                       $str .=" 
                           <td><img src=../$imageName width='120px'></td>
                          <td>$book_name</td>
                           <td>$added_by</td>
                             <td>$category </td>
                               
                                   <td>$number_of_books</td>
                                      <td>$body</td>
                                      <td>$date_time</td>
                                         
                                          
                        </tr>
                        "?>

                        <?php  } "
                      </table>
                      
                        <br>
                      </div>
                       </div>
                     
                    </div>
                   
                    <hr>";
          //End of friends of check
          ?>
      

          <?php
      //End while loop

      if($count > $limit) {
        $str .= "<input type='hidden' class='nextPage' value='" . ($page + 1) > "'>
                <input type='hidden' class='noMorePosts' value='false'>";
      } else {
        $str .= "<input type='hidden' class='noMorePosts' value='true'><p style='text-align: center;'></p>";
      }
    } //End if(mysqli_num_rows($data_query))
      echo $str;
  }


 public function loadSaleHistoryMine($data, $limit) {
    $page = $data['page'];
    $userLoggedIn = $this->user_obj->getUsername();

    if($page == 1) {
      $start = 0;
    } else {
      $start = ($page - 1) + $limit;
    };

    $str = ''; //String to return, initialize
    $data_query = mysqli_query($this->con, "SELECT * FROM sell_history WHERE owner='$userLoggedIn'  ORDER BY id DESC");


         

              

    


    if(mysqli_num_rows($data_query) > 0) {
      //There are results...
      $num_iterations = 0; //Number of results checked (not necs posted)
      $count = 1;
      $total=0;
      $tnumber_of_books=0;
//Create post content html
            $str .= "<div class='status_post'>
                      <div class='post_profile_pic'>
                       
                     
                      <div class='posted_by' style='color:#bdc3c7;'>
                        <a href=''> </a> &nbsp;&nbsp;&nbsp;&nbsp;<span class='time_message'></span><br>
                        
                      </div>
                     
       <table >
                        <tr>
                  
                          <th>Book Name </th>
                             <th>Price </th>
                              
                                   <th>Number of Books</th>
                                   <th>Description</th>
                                       <th>Date</th>
                                     
                        </tr>"
                        ;
        while($row = mysqli_fetch_array($data_query)) {

          $id = $row['id'];
          
          $book_name = $row['book_name'];
         
          $price = $row['price'];
          $number_of_books = $row['number_of_books'];
         $tnumber_of_books=$tnumber_of_books+$number_of_books;
         
          $total=$total+$price;
           $description = $row['description'];
 $selldate = $row['selldate'];
         
         
        

          ?>

          

        
<?php
                       $str .=" <tr>
                          <td>$book_name</td>
                                <td>$price</td>
                                   <td>$number_of_books</td>
                                      <td>$description</td>
                                   <td>$selldate</td>
                        </tr>
                        "?>

                        <?php  } "
                      </table>
                      
                        <br>
                      </div>
                       </div>
                     
                    </div>
                   
                    <hr>";
          //End of friends of check
          ?>


          <?php

     //End while loop
 echo '<h4>Total Sale : '.$total. ' Tk. Total Books : '.$tnumber_of_books.'</h5>';
      if($count > $limit) {
        $str .= "<input type='hidden' class='nextPage' value='" . ($page + 1) > "'>
                <input type='hidden' class='noMorePosts' value='false'>";
      } else {
        $str .= "<input type='hidden' class='noMorePosts' value='true'><p style='text-align: center;'></p>";
      }
    } //End if(mysqli_num_rows($data_query))
      echo $str;
  }
   public function loadRentHistoryMine($data, $limit) {
   
    $page = $data['page'];
    $userLoggedIn = $this->user_obj->getUsername();

    if($page == 1) {
      $start = 0;
    } else {
      $start = ($page - 1) + $limit;
    };

    $str = ''; //String to return, initialize
    $data_query = mysqli_query($this->con, "SELECT * FROM rent_history WHERE owner='$userLoggedIn'  ORDER BY rent_id DESC");

    if(mysqli_num_rows($data_query) > 0) {
      //There are results...
      $num_iterations = 0; //Number of results checked (not necs posted)
      $count = 1;
      $total=0;
      $tnumber_of_books=0;
$str .= "<div class='status_post'>
                      <div class='post_profile_pic'>
                       
                     
                      <div class='posted_by' style='color:#bdc3c7;'>
                        <a href=''> </a> &nbsp;&nbsp;&nbsp;&nbsp;<span class='time_message'></span><br>
                        
                      </div>
                     
                       <table >
                        <tr>
                          <th>Book Name </th>
                             <th>Customer Name </th>
                                   <th>Remaining Days</th>
                                    <th>Return Date</th>
                                         <th>Update Status</th>
                        </tr>"
                        ;
        while($row = mysqli_fetch_array($data_query)) {

          $rent_id = $row['rent_id'];
          $owner = $row['owner'];
          $book_name = $row['book_name'];
          $customer_name = $row['customer_name'];
          $rent_date = $row['rent_date'];
          $remain_date=date('Y-m-d')-$rent_date;
          $number_of_books = $row['number_of_books'];
          $description = $row['description'];
    
    $end_date = strtotime($rent_date);
$start_date = strtotime(date('Y-m-d'));
// Get the difference and divide into 
// total no. seconds 60/60/24 to get 
// number of days
$remain_date=($end_date - $start_date)/60/60/24;     


          //Friends of check, shows posts only from logged in user and friends of
        
          /*if($userLoggedIn == $added_by) {
            //own post
            $delete_button = "<button class='delete_button' id='post$id'><span  aria-hidden='true'>Returned</span></button>";
          } else {
            $delete_button = '';
          }*/
          ?>
<?php
                       $str .=" 
                          <td>$book_name</td>
                             
                                <td>$customer_name</td>
                                     <td>$remain_date days</td>
                                <td>$rent_date</td>
                              
                                     
                                      <td><button class='delete_button' id='post$rent_id'><span  aria-hidden='true'>Returned</span></button></td>
                        </tr>
                   "?>

                        <?php  "
                      </table>
                      
                        <br>
                      </div>
                       </div>
                     
                    </div>
                   
                    <hr>";
          //End of friends of check
          ?>

          <script>
            $(document).ready(function() {
              $('#post<?php echo $rent_id; ?>').on('click', function() {
                bootbox.confirm('Are you returned the book in your store?', function(result) {
                  $.post("includes/form_handlers/returnbook.php?book_name=<?php echo $book_name; ?>&rent_id=<?php echo $rent_id; ?>", {result: result});
                  if(result) {
                    location.reload();
                  }
                });
              });
            });
          </script>

          <?php
        
}
      } //End while loop
$count=0;
      if($count > $limit) {
        $str .= "<input type='hidden' class='nextPage' value='" . ($page + 1) > "'>
                <input type='hidden' class='noMorePosts' value='false'>";
      } else {
        $str .= "<input type='hidden' class='noMorePosts' value='true'><p style='text-align: center;'></p>";
      }
       echo $str;
    } //End if(mysqli_num_rows($data_query))
     
   public function loadRentedBook($data, $limit) {
   
    $page = $data['page'];
    $userLoggedIn = $this->user_obj->getUsername();

    if($page == 1) {
      $start = 0;
    } else {
      $start = ($page - 1) + $limit;
    };

    $str = ''; //String to return, initialize
    $data_query = mysqli_query($this->con, "SELECT * FROM rent_history WHERE customer_name='$userLoggedIn'  ORDER BY rent_id DESC");

    if(mysqli_num_rows($data_query) > 0) {
      //There are results...
      $num_iterations = 0; //Number of results checked (not necs posted)
      $count = 1;
      $total=0;
      $tnumber_of_books=0;
$str .= "<div class='status_post'>
                      <div class='post_profile_pic'>
                       
                     
                      <div class='posted_by' style='color:#bdc3c7;'>
                        <a href=''> </a> &nbsp;&nbsp;&nbsp;&nbsp;<span class='time_message'></span><br>
                        
                      </div>
                     
                       <table >
                        <tr>
                          <th>Book Name </th>
                             <th>Owner Name </th>
                                   <th>Remaining Days</th>
                                    <th>Return Date</th>
                                         
                        </tr>"
                        ;
        while($row = mysqli_fetch_array($data_query)) {

          $rent_id = $row['rent_id'];
          $owner = $row['owner'];
          $book_name = $row['book_name'];
          $customer_name = $row['customer_name'];
          $rent_date = $row['rent_date'];
          $remain_date=date('Y-m-d')-$rent_date;
          $number_of_books = $row['number_of_books'];
          $description = $row['description'];
    
    $end_date = strtotime($rent_date);
$start_date = strtotime(date('Y-m-d'));
// Get the difference and divide into 
// total no. seconds 60/60/24 to get 
// number of days
$remain_date=($end_date - $start_date)/60/60/24;     


          //Friends of check, shows posts only from logged in user and friends of
        
          /*if($userLoggedIn == $added_by) {
            //own post
            $delete_button = "<button class='delete_button' id='post$id'><span  aria-hidden='true'>Returned</span></button>";
          } else {
            $delete_button = '';
          }*/
          ?>
<?php
                       $str .=" 
                          <td>$book_name</td>
                             
                                <td>$owner</td>
                                     <td>$remain_date days</td>
                                <td>$rent_date</td>
                              
                                     
                                     
                        </tr>
                   "?>

                        <?php  "
                      </table>
                      
                        <br>
                      </div>
                       </div>
                     
                    </div>
                   
                    <hr>";
          //End of friends of check
          ?>

          <script>
            $(document).ready(function() {
              $('#post<?php echo $rent_id; ?>').on('click', function() {
                bootbox.confirm('Are you returned the book in your store?', function(result) {
                  $.post("includes/form_handlers/returnbook.php?book_name=<?php echo $book_name; ?>&rent_id=<?php echo $rent_id; ?>", {result: result});
                  if(result) {
                    location.reload();
                  }
                });
              });
            });
          </script>

          <?php
        
}
      } //End while loop
$count=0;
      if($count > $limit) {
        $str .= "<input type='hidden' class='nextPage' value='" . ($page + 1) > "'>
                <input type='hidden' class='noMorePosts' value='false'>";
      } else {
        $str .= "<input type='hidden' class='noMorePosts' value='true'><p style='text-align: center;'></p>";
      }
       echo $str;
    } //End if(mysqli_num_rows($data_query))
     
  

  public function loadPostsFriends($data, $limit) {
    $page = $data['page'];
    $userLoggedIn = $this->user_obj->getUsername();

    if($page == 1) {
      $start = 0;
    } else {
      $start = ($page - 1) + $limit;
    };

    $str = ''; //String to return, initialize
    $data_query = mysqli_query($this->con, "SELECT * FROM posts  WHERE deleted='no' ORDER BY id DESC");

    if(mysqli_num_rows($data_query) > 0) {
      //There are results...
      $num_iterations = 0; //Number of results checked (not necs posted)
      $count = 1;

        while($row = mysqli_fetch_array($data_query)) {
          $id = $row['id'];
          $body = $row['body'];
          $book_name = $row['book_name'];
          $category = $row['category'];
          $deal_type = $row['deal_type'];
          $price = $row['price'];
          $added_by = $row['added_by'];
          $date_time = $row['date_added'];
           $imageName = $row['image_name'];
           $discount = $row['discount'];
           $start_d_date = $row['start_d_date'];
            $last_d_date = $row['last_d_date'];


          //Prepare user_to string to be included if necessary
          if($row['user_to'] == 'none') {
            $user_to  = '';
          } else {
            $user_to_obj = new User($this->con, $row['user_to']); //New instance of user class
            $user_to_name = $user_to_obj->getFirstAndLastName(); //Gets first and last name of user
            $user_to = "to <a href='" . $row['user_to'] ."'>" . $user_to_name . "</a>"; //Return link to the profile page
          }

          //Check if user who posted has a closed accounts (posts will not show)
          $added_by_obj = new User($this->con, $added_by);
          if($added_by_obj->isClosed()) {
            continue; //Returns to start of while loop
          }

          //Friends of check, shows posts only from logged in user and friends of
          $user_logged_obj = new User($this->con, $userLoggedIn);
          if($user_logged_obj->allFriend($added_by)) {

          if($num_iterations++ < $start){ //Gets to all posts to be loaded before ending
            continue;
          }

          if($count > $limit) {
            break; //Once limit posts have been loaded, break;
          } else {
            $count++;
          };

          if($userLoggedIn == $added_by) {
            //own post
            $delete_button = "<button class='delete_button' id='post$id'><span  aria-hidden='true'>Unpublish</span></button>";
          } else {
            $delete_button = '';
          }

          $user_details_query = mysqli_query($this->con, "SELECT first_name, last_name, profile_pic FROM users WHERE username='$added_by'");
          $user_row = mysqli_fetch_array($user_details_query);
          //$first_name = $user_row['first_name'];
         // $last_name = $user_row['last_name'];
         // $profile_pic = $user_row['profile_pic'];

          ?>

              <script>
                function toggle<?php echo $id; ?>() {
                  //Toggle show and hide for comments based on $id
                  var target = $(event.target);
                  if(!target.is('a')) { //Excludes the name link
                    var element = document.getElementById('toggleComment<?php echo $id; ?>');
                    if(element.style.display == 'block') {
                      element.style.display = 'none';
                    } else {
                      element.style.display = 'block';
                    }
                  }
                }
              </script>

          <?php

          $comments_check = mysqli_query($this->con, "SELECT * FROM comments WHERE post_id='$id'");
          $comments_check_num = mysqli_num_rows($comments_check); //Number of results of comments per post

                //Timeframe
                $date_time_now = date("Y-m-d H:i:s");
                $start_date = new DateTime($date_time); //Time of post
                $end_date = new DateTime($date_time_now); //Current time
                $interval = $start_date->diff($end_date); //Difference between dates

                if($interval->y >= 1) {
                    if($interval == 1) {
                      $time_message = $interval->y . " year ago"; //1 year ago
                    } else {
                      $time_message = $interval->y . " years ago"; //1+ year ago
                    };
                } else if ($interval-> m >= 1) {
                    if($interval->d == 0) {
                      $days = " ago";
                    } else if($interval->d == 1) {
                      $days = $interval->d . " day ago";
                    } else {
                      $days = $interval->d . " days ago";
                    };
                    if($interval->m == 1) {
                      $time_message = $interval->m . " month". $days;
                    } else {
                      $time_message = $interval->m . " months". $days;
                    };
                } else if($interval->d >= 1) {
                    if($interval->d == 1) {
                      $time_message = "Yesterday";
                    } else {
                      $time_message = $interval->d . " days ago";
                    }
                } else if($interval->h >= 1) {
                  if($interval->h == 1) {
                    $time_message = $interval->h . " hour ago";
                  } else {
                    $time_message = $interval->h . " hours ago";
                  }
                } else if($interval->i >= 1) {
                  if($interval->i == 1) {
                    $time_message = $interval->i . " minute ago";
                  } else {
                    $time_message = $interval->i . " minutes ago";
                  }
                } else {
                    if($interval->s < 30) {
                      $time_message = "Just now";
                    } else {
                      $time_message = $interval->s . " seconds ago";
                    }
                }; //END TIME FRAME

                if ($discount==0) {
                   //Create post content html
            $str .= "<div class='status_post' onClick='javascript:toggle$id()'>
                      <div class='post_profile_pic'>
                       
                     
                      <div class='posted_by' style='color:#bdc3c7;'>
                        <a href='$added_by'> user </a> $user_to &nbsp;&nbsp;&nbsp;&nbsp;<span class='time_message'>$time_message</span><br>
                        $delete_button
                      </div>
                      <div id='post_body'>
                      <img src=$imageName width='140' height='150'><br>
                        Book Name : $book_name
                        <br>
                       
                        Category : $category
                        <br>
                      
                       Price : $price
                        <br>
                          $deal_type
                        <br>
                        
                       Description : $body
                        <br>
                        <br>
                        <br>
                      </div>
                       </div>
                      <div class='newsfeedPostOptions'>
                        <iframe src='like.php?post_id=$id' scrolling='no'></iframe><br>
                        <span class='comment_count'></span>
                      </div>
                    </div>
                    <div class='post_comment' id='toggleComment$id' style='display: none;'>
                      <iframe src='comment_frame.php?post_id=$id' id='comment_iframe' frameborder=0></iframe>
                    </div>
                    <hr>";
                }

                else{
                  $d_price=0;
                //  $d_price= $price-$discount;

 $str .= "";

                }

   
          } //End of friends of check
          ?>

          <script>
            $(document).ready(function() {
              $('#post<?php echo $id; ?>').on('click', function() {
                bootbox.confirm('Are you sure you want to Unpublish this post?', function(result) {
                  $.post("includes/form_handlers/unpublish_post.php?post_id=<?php echo $id; ?>", {result: result});
                  if(result) {
                    location.reload();
                  }
                });
              });
            });
          </script>

          <?php
      } //End while loop

      if($count > $limit) {
        $str .= "<input type='hidden' class='nextPage' value='" . ($page + 1) > "'>
                <input type='hidden' class='noMorePosts' value='false'>";
      } else {
        $str .= "<input type='hidden' class='noMorePosts' value='true'><p style='text-align: center;'>No more posts to show!</p>";
      }
    } //End if(mysqli_num_rows($data_query))
      echo $str;
  }
  public function loadProfilePosts($data, $limit) {
    $page = $data['page'];
    $profileUser = $data['profileUsername'];
    $userLoggedIn = $this->user_obj->getUsername();

    if($page == 1) {
      $start = 0;
    } else {
      $start = ($page - 1) + $limit;
    };

    $str = ''; //String to return, initialize
    $data_query = mysqli_query($this->con, "SELECT * FROM posts WHERE deleted='no' AND ((added_by='$profileUser' AND user_to='none') OR user_to='$profileUser') ORDER BY id DESC"); //Posts not to other users, or posts from other users to profile user

    if(mysqli_num_rows($data_query) > 0) {
      //There are results...
      $num_iterations = 0; //Number of results checked (not necs posted)
      $count = 1;

        while($row = mysqli_fetch_array($data_query)) {
            $id = $row['id'];
          $body = $row['body'];
          $book_name = $row['book_name'];
          $category = $row['category'];
          $deal_type = $row['deal_type'];
          $price = $row['price'];
          $added_by = $row['added_by'];
          $date_time = $row['date_added'];
           $imageName = $row['image_name'];

          if($num_iterations++ < $start){ //Gets to all posts to be loaded before ending
            continue;
          }

          if($count > $limit) {
            break; //Once limit posts have been loaded, break;
          } else {
            $count++;
          };

          if($userLoggedIn == $added_by) {
            //own post
            $delete_button = "<button class='delete_button' id='post$id'><span class='glyphicon glyphicon-remove' aria-hidden='true'></span></button>";
          } else {
            $delete_button = '';
          }

          $user_details_query = mysqli_query($this->con, "SELECT first_name, last_name, profile_pic FROM users WHERE username='$added_by'");
          $user_row = mysqli_fetch_array($user_details_query);
          $first_name = $user_row['first_name'];
          $last_name = $user_row['last_name'];
          $profile_pic = $user_row['profile_pic'];

          ?>

              <script>
                function toggle<?php echo $id; ?>() {
                  //Toggle show and hide for comments based on $id
                  var target = $(event.target);
                  if(!target.is('a')) { //Excludes the name link
                    var element = document.getElementById('toggleComment<?php echo $id; ?>');
                    if(element.style.display == 'block') {
                      element.style.display = 'none';
                    } else {
                      element.style.display = 'block';
                    }
                  }
                }
              </script>

          <?php

          $comments_check = mysqli_query($this->con, "SELECT * FROM comments WHERE post_id='$id'");
          $comments_check_num = mysqli_num_rows($comments_check); //Number of results of comments per post

                //Timeframe
                $date_time_now = date("Y-m-d H:i:s");
                $start_date = new DateTime($date_time); //Time of post
                $end_date = new DateTime($date_time_now); //Current time
                $interval = $start_date->diff($end_date); //Difference between dates

                if($interval->y >= 1) {
                    if($interval == 1) {
                      $time_message = $interval->y . " year ago"; //1 year ago
                    } else {
                      $time_message = $interval->y . " years ago"; //1+ year ago
                    };
                } else if ($interval-> m >= 1) {
                    if($interval->d == 0) {
                      $days = " ago";
                    } else if($interval->d == 1) {
                      $days = $interval->d . " day ago";
                    } else {
                      $days = $interval->d . " days ago";
                    };
                    if($interval->m == 1) {
                      $time_message = $interval->m . " month". $days;
                    } else {
                      $time_message = $interval->m . " months". $days;
                    };
                } else if($interval->d >= 1) {
                    if($interval->d == 1) {
                      $time_message = "Yesterday";
                    } else {
                      $time_message = $interval->d . " days ago";
                    }
                } else if($interval->h >= 1) {
                  if($interval->h == 1) {
                    $time_message = $interval->h . " hour ago";
                  } else {
                    $time_message = $interval->h . " hours ago";
                  }
                } else if($interval->i >= 1) {
                  if($interval->i == 1) {
                    $time_message = $interval->i . " minute ago";
                  } else {
                    $time_message = $interval->i . " minutes ago";
                  }
                } else {
                    if($interval->s < 30) {
                      $time_message = "Just now";
                    } else {
                      $time_message = $interval->s . " seconds ago";
                    }
                }; //END TIME FRAME

    //Create post content html
            $str .= "<div class='status_post' onClick='javascript:toggle$id()'>
                      <div class='post_profile_pic'>
                        <img src='$profile_pic' width='50'>
                      </div>
                      <div class='posted_by' style='color:#bdc3c7;'>
                        <a href='$added_by'> $first_name $last_name </a>&nbsp;&nbsp;&nbsp;&nbsp;<span class='time_message'>$time_message</span><br>
                        $delete_button
                      </div>
                      <div id='post_body'>
                      <img src=$imageName width='140' height='150'><br>
                        Book Name : $book_name
                        <br>
                       
                        Category : $category
                        <br>
                         
                         For $deal_type
                        <br>
                        
                       Description : $body
                        <br>
                        <br>
                        <br>
                      </div>
                      <div class='newsfeedPostOptions'>
                        <iframe src='like.php?post_id=$id' scrolling='no'></iframe><br>
                        <span class='comment_count'>Comments&nbsp;($comments_check_num)</span>
                      </div>
                    </div>
                    <div class='post_comment' id='toggleComment$id' style='display: none;'>
                      <iframe src='comment_frame.php?post_id=$id' id='comment_iframe' frameborder=0></iframe>
                    </div>
                    <hr>";
          ?>

          <script>
            $(document).ready(function() {
              $('#post<?php echo $id; ?>').on('click', function() {
                bootbox.confirm('Are you sure you want to delete this post?', function(result) {
                  $.post("includes/form_handlers/delete_post.php?post_id=<?php echo $id; ?>", {result: result});
                  if(result) {
                    location.reload();
                  }
                });
              });
            });
          </script>

          <?php
      } //End while loop

      if($count > $limit) {
        $str .= "<input type='hidden' class='nextPage' value='" . ($page + 1) > "'>
                <input type='hidden' class='noMorePosts' value='false'>";
      } else {
        $str .= "<input type='hidden' class='noMorePosts' value='true'><p style='text-align: center;'>No more posts to show!</p>";
      }
    } //End if(mysqli_num_rows($data_query))
      echo $str;
  }

  public function getSinglePost($post_id) {
    $userLoggedIn = $this->user_obj->getUsername();

    $opened_query = mysqli_query($this->con, "UPDATE notifications SET opened='yes' WHERE user_to='$userLoggedIn' AND link LIKE '%=$post_id'");

		$str = ""; //String to return
		$data_query = mysqli_query($this->con, "SELECT * FROM posts WHERE deleted='no' AND id='$post_id'");

		if(mysqli_num_rows($data_query) > 0) {

          $row = mysqli_fetch_array($data_query);
          $id = $row['id'];
          $body = $row['body'];
          $added_by = $row['added_by'];
          $date_time = $row['date_added'];

          //Prepare user_to string to be included if necessary
          if($row['user_to'] == 'none') {
            $user_to  = '';
          } else {
            $user_to_obj = new User($this->con, $row['user_to']); //New instance of user class
            $user_to_name = $user_to_obj->getFirstAndLastName(); //Gets first and last name of user
            $user_to = "to <a href='" . $row['user_to'] ."'>" . $user_to_name . "</a>"; //Return link to the profile page
          }

          //Check if user who posted has a closed accounts (posts will not show)
          $added_by_obj = new User($this->con, $added_by);
          if($added_by_obj->isClosed()) {
            return;
          }

          //Friends of check, shows posts only from logged in user and friends of
          $user_logged_obj = new User($this->con, $userLoggedIn);
          if($user_logged_obj->isFriend($added_by)) {

          if($userLoggedIn == $added_by) {
            //own post
            $delete_button = "<button class='delete_button' id='post$id'><span class='glyphicon glyphicon-remove' aria-hidden='true'></span></button>";
          } else {
            $delete_button = '';
          }

          $user_details_query = mysqli_query($this->con, "SELECT first_name, last_name, profile_pic FROM users WHERE username='$added_by'");
          $user_row = mysqli_fetch_array($user_details_query);
          $first_name = $user_row['first_name'];
          $last_name = $user_row['last_name'];
          $profile_pic = $user_row['profile_pic'];

          ?>

              <script>
                function toggle<?php echo $id; ?>() {
                  //Toggle show and hide for comments based on $id
                  var target = $(event.target);
                  if(!target.is('a')) { //Excludes the name link
                    var element = document.getElementById('toggleComment<?php echo $id; ?>');
                    if(element.style.display == 'block') {
                      element.style.display = 'none';
                    } else {
                      element.style.display = 'block';
                    }
                  }
                }
              </script>

          <?php

          $comments_check = mysqli_query($this->con, "SELECT * FROM comments WHERE post_id='$id'");
          $comments_check_num = mysqli_num_rows($comments_check); //Number of results of comments per post

                //Timeframe
                $date_time_now = date("Y-m-d H:i:s");
                $start_date = new DateTime($date_time); //Time of post
                $end_date = new DateTime($date_time_now); //Current time
                $interval = $start_date->diff($end_date); //Difference between dates

                if($interval->y >= 1) {
                    if($interval == 1) {
                      $time_message = $interval->y . " year ago"; //1 year ago
                    } else {
                      $time_message = $interval->y . " years ago"; //1+ year ago
                    };
                } else if ($interval-> m >= 1) {
                    if($interval->d == 0) {
                      $days = " ago";
                    } else if($interval->d == 1) {
                      $days = $interval->d . " day ago";
                    } else {
                      $days = $interval->d . " days ago";
                    };
                    if($interval->m == 1) {
                      $time_message = $interval->m . " month". $days;
                    } else {
                      $time_message = $interval->m . " months". $days;
                    };
                } else if($interval->d >= 1) {
                    if($interval->d == 1) {
                      $time_message = "Yesterday";
                    } else {
                      $time_message = $interval->d . " days ago";
                    }
                } else if($interval->h >= 1) {
                  if($interval->h == 1) {
                    $time_message = $interval->h . " hour ago";
                  } else {
                    $time_message = $interval->h . " hours ago";
                  }
                } else if($interval->i >= 1) {
                  if($interval->i == 1) {
                    $time_message = $interval->i . " minute ago";
                  } else {
                    $time_message = $interval->i . " minutes ago";
                  }
                } else {
                    if($interval->s < 30) {
                      $time_message = "Just now";
                    } else {
                      $time_message = $interval->s . " seconds ago";
                    }
                }; //END TIME FRAME

    //Create post content html
            $str .= "<div class='status_post' onClick='javascript:toggle$id()'>
                      <div class='post_profile_pic'>
                        <img src='$profile_pic' width='50'>
                      </div>
                      <div class='posted_by' style='color:#bdc3c7;'>
                        <a href='$added_by'> $first_name $last_name </a> $user_to &nbsp;&nbsp;&nbsp;&nbsp;<span class='time_message'>$time_message</span><br>
                        $delete_button
                      </div>
                      <div id='post_body'>
                        $body
                        <br>
                        <br>
                        <br>
                      </div>
                      <div class='newsfeedPostOptions'>
                        <iframe src='like.php?post_id=$id' scrolling='no'></iframe><br>
                        <span class='comment_count'>Comments&nbsp;($comments_check_num)</span>
                      </div>
                    </div>
                    <div class='post_comment' id='toggleComment$id' style='display: none;'>
                      <iframe src='comment_frame.php?post_id=$id' id='comment_iframe' frameborder=0></iframe>
                    </div>
                    <hr>";
          ?>
          <script>
            $(document).ready(function() {
              $('#post<?php echo $id; ?>').on('click', function() {
                bootbox.confirm('Are you sure you want to delete this post?', function(result) {
                  $.post("includes/form_handlers/delete_post.php?post_id=<?php echo $id; ?>", {result: result});
                  if(result) {
                    location.reload();
                  }
                });
              });
            });
          </script>
          <?php
        } else { //friend check else
          echo "<p>You cannot see this post because you are not friends with this user.</p>";
          return;
        } //End of friends of check
    } else { //if query else
      echo "<p>No posts found.</p>";
      return;
    } //End if(mysqli_num_rows($data_query))
      echo $str;
  }

} //End Class


 ?>
<?php
function phpAlert($msg) {
    echo '<script type="text/javascript">alert("' . $msg . '")</script>';
}
?>