<?php

require '../../config/config.php';

if(isset($_GET['book_name'])) {
  //If post id has been provided;
  $post_id = $_GET['book_name'];
  $rent_id = $_GET['rent_id'];
}

if(isset($_POST['result'])) {
  //Delete yes or no answered
  if($_POST[result] == true) {
    $query - mysqli_query($con, "UPDATE posts SET deleted='no',deal_type='rent',number_of_books=number_of_books+1 WHERE book_name='$post_id'"); //Hides, does not remove from DB
    $query - mysqli_query($con, "DELETE from rent_history WHERE rent_id='$rent_id'");
  }
}

?>
